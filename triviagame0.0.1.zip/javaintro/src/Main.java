import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // excercise 1

        int answerA1 = 1;
        int answerA2 = 2;
        int answerA3 = 3;

        System.out.println("Is the answer 1, 2, or 3?");

        Scanner scanner = new
                Scanner(System.in);
        answerA1 = scanner.nextInt();
        System.out.println(answerA1);

        if(answerA1 == 1){
            System.out.println("Correct!");
        } else {
            System.out.println("Incorrect");
        }
        int answerB1 = 1;
        int answerB2 = 2;
        int answerB3 = 3;

        System.out.println("Is the answer 1, 2, or 3?");

                new Scanner(System.in);
        answerB3 = scanner.nextInt();
        System.out.println(answerB3);

        if(answerB3 == 3){
            System.out.println("Correct!");
        } else {
            System.out.println("Incorrect");
        }

        int answerC1 = 1;
        int answerC2 = 2;
        int answerC3 = 3;

        System.out.println("Is the answer 1, 2, or 3?");

        new Scanner(System.in);
        answerC2 = scanner.nextInt();
        System.out.println(answerC2);

        if(answerC2 == 2){
            System.out.println("Correct!");
        } else {
            System.out.println("Incorrect");
        }
    }
}